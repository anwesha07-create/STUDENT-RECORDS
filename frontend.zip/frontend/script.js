const form = document.getElementById('studentForm');
const studentList = document.getElementById('studentList');

// Fetch and display students
async function fetchStudents() {
  try {
    const res = await fetch('http://localhost:5000/students');
    const students = await res.json();

    studentList.innerHTML = "";

    students.forEach(s => {
      const row = document.createElement('tr');
      row.className = "hover:bg-gray-100 transition";

      row.innerHTML = `
        <td class="p-3">${s.name}</td>
        <td class="p-3">${s.roll}</td>
        <td class="p-3">${s.course}</td>
        <td class="p-3">${s.year}</td>
        <td class="p-3">
          <button 
            class="bg-red-500 text-white px-4 py-2 rounded" 
            onclick="deleteStudent(${s.id})">
            Delete
          </button>
        </td>
      `;

      studentList.appendChild(row);
    });
  } catch (err) {
    console.error("Error fetching students:", err);
  }
}

// Add student
form.addEventListener('submit', async (e) => {
  e.preventDefault();

  const student = {
    name: document.getElementById('name').value.trim(),
    roll: document.getElementById('roll').value.trim(),
    course: document.getElementById('course').value.trim(),
    year: document.getElementById('year').value.trim(),
  };

  try {
    await fetch('http://localhost:5000/students', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(student),
    });

    form.reset();
    fetchStudents();
  } catch (err) {
    console.error("Error adding student:", err);
  }
});

// Delete student
async function deleteStudent(id) {
  try {
    await fetch(`http://localhost:5000/students/${id}`, {
      method: 'DELETE'
    });

    fetchStudents();
  } catch (err) {
    console.error("Error deleting student:", err);
  }
}

// Load students on page load
window.onload = fetchStudents;
